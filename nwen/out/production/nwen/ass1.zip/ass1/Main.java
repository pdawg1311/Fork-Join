public class Main {


    public static void main(String[] args){
        TestFloat t = new TestFloat();
        t.testMParallelSorter3();
    }

}
